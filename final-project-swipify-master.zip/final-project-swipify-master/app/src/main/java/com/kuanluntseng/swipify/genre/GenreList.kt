package com.kuanluntseng.swipify.genre

import com.kuanluntseng.swipify.utils.Utils


//class GenreList {
//    private val genreListItems: List<GenreItem> = initListItems()
//
//    fun initListItems(): List<GenreItem> {
//        val genres = Utils.genreSeeds
//        val genresItems = genres.map { GenreItem(it, false) }
//        return genresItems
//    }
//
//    fun getGenreListItems(): List<GenreItem> {
//        return this.genreListItems
//    }
//
//    operator fun get(position: Int): GenreItem {
//        return genreListItems[position]
//    }
//
//}