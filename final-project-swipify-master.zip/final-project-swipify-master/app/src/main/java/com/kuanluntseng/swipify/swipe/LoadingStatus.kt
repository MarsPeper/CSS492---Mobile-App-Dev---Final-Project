package com.kuanluntseng.swipify.swipe

enum class LoadingStatus {
    LOADING,
    ERROR,
    SUCCESS
}