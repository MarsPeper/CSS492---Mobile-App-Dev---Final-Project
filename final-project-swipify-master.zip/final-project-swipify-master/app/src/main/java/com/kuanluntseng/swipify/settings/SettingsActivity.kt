package com.kuanluntseng.swipify.settings

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.kuanluntseng.swipify.R

class SettingsActivity : AppCompatActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
    }
}