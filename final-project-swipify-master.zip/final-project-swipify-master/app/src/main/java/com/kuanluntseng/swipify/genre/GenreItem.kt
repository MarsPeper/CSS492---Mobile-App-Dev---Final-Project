package com.kuanluntseng.swipify.genre

data class GenreItem(val name: String, var selected: Boolean)